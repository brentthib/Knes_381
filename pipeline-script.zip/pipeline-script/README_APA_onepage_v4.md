# README — APA 7 (Markdown → Word)

## Overview
Write in Markdown → convert to APA-formatted Word with one command.

## Requirements
- Pandoc (required)
- LibreOffice (optional for PDF)

## Files
- `my-paper.md` (edit)
- `convert.sh` / `Convert-APA.ps1`
- `apa-reference.docx` (do not edit)
- `apa-filter.lua` (do not edit)

## Step 1 — Fill YAML in `my-paper.md`
- title, author, affiliation, course, instructor, due-date  
- bibliography: references.bib  

## Step 2 — Citations
Example:  
`Exercise induces fatigue [@Allen2008]`

## Step 3 — Convert
- Mac/Linux: `./convert.sh my-paper.md`
- Windows: `.\Convert-APA.ps1 my-paper.md`

## Output
- `my-paper_APA.docx` (APA formatted)

## Optional PDF
`./convert.sh my-paper.md output.pdf`

## Notes
- Do not edit template/filter files  
- Missing YAML → broken title page  
- Missing bibliography → no references  

## Workflow
1. Write (Markdown)  
2. Run command  
3. Submit (*.md, *.bib, and *.docx or *.pdf)  
   - Submit originals to verify authorship and citation integrity  

## Quick command
`./script.sh input.md output.docx (or output.pdf)`
