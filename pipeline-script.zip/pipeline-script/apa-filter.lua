--[[
  apa-filter.lua
  Pandoc Lua filter — APA 7th Edition (Student Paper)

  Reads YAML metadata from the markdown document and prepends:
    1. A properly formatted APA title page
    2. An abstract page (if `abstract:` is present in the YAML)

  All formatting is delegated to custom paragraph styles defined in
  apa-reference.docx, so the output is only meaningful when the filter
  is used together with --reference-doc=apa-reference.docx.

  Required YAML fields:
    title        — paper title (bold, centered on title page)
    author       — student name(s)
    affiliation  — department and institution
    course       — course name and number
    instructor   — instructor name
    due-date     — assignment due date

  Optional YAML fields:
    abstract     — abstract text (triggers a second page before body)
    keywords     — comma-separated keyword list
--]]

-- ─── Helpers ──────────────────────────────────────────────────────────────────

-- Safely stringify a metadata value (handles strings, Inlines, MetaBlocks, etc.)
local function str(val)
  if val == nil then return nil end
  local ok, result = pcall(pandoc.utils.stringify, val)
  if ok and result ~= "" then return result end
  return nil
end

-- Stringify a pandoc author metadata value.
--
-- Pandoc represents author: as MetaInlines (single author's inline content)
-- OR as MetaList (list of authors). Inline elements have a .t field;
-- MetaList entries (which are themselves MetaInlines) do not.
-- We use that distinction to decide whether to join a list or stringify directly.
local function stringify_authors(val)
  if val == nil then return nil end
  local ok, first = pcall(function() return val[1] end)
  if not ok or first == nil then
    return str(val)
  end
  -- If the first element has a .t field it is an Inline element, which means
  -- val itself is MetaInlines — i.e. a single author's name content.
  if type(first) == "table" and first.t ~= nil then
    return str(val)
  end
  -- Otherwise val is a MetaList; each element is one author's MetaInlines.
  local names = {}
  for _, a in ipairs(val) do
    -- MetaMap from a structured author block (has a "name" key)
    if type(a) == "table" and a.name then
      table.insert(names, str(a.name))
    else
      local s = str(a)
      if s and s ~= "" then table.insert(names, s) end
    end
  end
  if #names == 0 then return str(val) end
  return table.concat(names, "; ")
end

-- Wrap a single Paragraph inside a Div with a named custom-style.
-- Pandoc maps the custom-style attribute to the matching style in the
-- reference.docx, so each piece of the title page gets the right look.
local function styled(style_name, para)
  return pandoc.Div(
    { para },
    pandoc.Attr("", {}, { ["custom-style"] = style_name })
  )
end

-- A centered-bold paragraph (used for the paper title).
local function title_para(text)
  return styled("TitlePageTitle",
    pandoc.Para({ pandoc.Strong({ pandoc.Str(text) }) })
  )
end

-- A centered plain paragraph (used for author, affiliation, etc.).
local function center_para(text)
  return styled("TitlePageText",
    pandoc.Para({ pandoc.Str(text) })
  )
end

-- An empty centered paragraph (vertical white-space on the title page).
local function blank()
  return styled("TitlePageText", pandoc.Para({ pandoc.Str("") }))
end

-- Raw OpenXML page break block.
local function page_break()
  return pandoc.RawBlock("openxml",
    '<w:p><w:r><w:br w:type="page"/></w:r></w:p>'
  )
end

-- ─── Main filter ──────────────────────────────────────────────────────────────

function Pandoc(doc)
  local m = doc.meta

  local paper_title  = str(m.title)
  local author       = stringify_authors(m.author)
  local affiliation  = str(m.affiliation)
  local course       = str(m.course)
  local instructor   = str(m.instructor)
  local due_date     = str(m["due-date"])
  local abstract_val = m.abstract
  local keywords_val = str(m.keywords)

  -- Nothing useful in YAML → leave document untouched
  if not paper_title and not author then
    return doc
  end

  -- ── Title page ────────────────────────────────────────────────────────────
  local blocks = pandoc.List()

  -- APA spec: title begins in the upper half of the page.
  -- Three blank lines at 12pt double-spaced gives roughly that position.
  blocks:insert(blank())
  blocks:insert(blank())
  blocks:insert(blank())

  if paper_title then blocks:insert(title_para(paper_title)) end

  blocks:insert(blank())  -- one blank line separating title from author info

  if author      then blocks:insert(center_para(author))      end
  if affiliation then blocks:insert(center_para(affiliation)) end
  if course      then blocks:insert(center_para(course))      end
  if instructor  then blocks:insert(center_para(instructor))  end
  if due_date    then blocks:insert(center_para(due_date))    end

  blocks:insert(page_break())

  -- ── Abstract page (optional) ──────────────────────────────────────────────
  if abstract_val ~= nil then
    local abstract_text = str(abstract_val) or ""

    -- "Abstract" heading
    blocks:insert(
      styled("APAAbstractTitle",
        pandoc.Para({ pandoc.Strong({ pandoc.Str("Abstract") }) })
      )
    )

    -- Abstract body (no first-line indent per APA 7)
    blocks:insert(
      styled("APAAbstractText",
        pandoc.Para({ pandoc.Str(abstract_text) })
      )
    )

    -- Keywords line:  Keywords: word1, word2, word3
    if keywords_val then
      blocks:insert(
        styled("APAAbstractText",
          pandoc.Para({
            pandoc.Emph({ pandoc.Str("Keywords:") }),
            pandoc.Space(),
            pandoc.Str(keywords_val),
          })
        )
      )
    end

    blocks:insert(page_break())
  end

  -- ── Append original document body ─────────────────────────────────────────
  blocks:extend(doc.blocks)

  -- ── Suppress Pandoc's auto-generated title block ──────────────────────────
  -- Pandoc's docx writer inserts Title/Author/Abstract styled paragraphs from
  -- these metadata keys when they are present.  We've already built our own
  -- title page, so we clear these fields to avoid duplication.
  -- We preserve them as *-meta keys so document properties (e.g. File → Info)
  -- are still populated in Word.
  m["title-meta"]    = m["title-meta"]    or m.title
  m["author-meta"]   = m["author-meta"]   or m.author
  m.title    = nil
  m.author   = nil
  m.abstract = nil

  return pandoc.Pandoc(blocks, m)
end
