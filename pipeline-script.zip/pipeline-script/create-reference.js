// create-reference.js
// Generates apa-reference.docx — the Pandoc reference document for APA 7th edition formatting.
// Run once: node create-reference.js

const {
  Document, Packer, Paragraph, TextRun,
  AlignmentType, Header, PageNumber,
} = require('docx');
const fs = require('fs');

const TNR  = "Times New Roman";
const PT12 = 24;   // 12pt expressed in half-points (docx-js unit)
const DBL  = { line: 480, lineRule: "auto" };  // double spacing (480 = 2 × 240)
const MARGINS = { top: 1440, right: 1440, bottom: 1440, left: 1440 };  // 1 inch in twips

// ─── Style definitions ────────────────────────────────────────────────────────

const paragraphStyles = [

  // Normal — body text: TNR 12pt, double-spaced, 0.5" first-line indent
  {
    id: "Normal", name: "Normal",
    run: { font: TNR, size: PT12, color: "000000" },
    paragraph: {
      alignment: AlignmentType.BOTH,
      spacing: DBL,
      indent: { firstLine: 720 },   // 0.5" = 720 twips
    },
  },

  // APA Level-1 heading: centered, bold, same size as body
  {
    id: "Heading1", name: "Heading 1",
    basedOn: "Normal", next: "Normal",
    run: { font: TNR, size: PT12, bold: true, color: "000000" },
    paragraph: {
      alignment: AlignmentType.CENTER,
      spacing: DBL,
      indent: { firstLine: 0 },
    },
  },

  // APA Level-2 heading: flush left, bold
  {
    id: "Heading2", name: "Heading 2",
    basedOn: "Normal", next: "Normal",
    run: { font: TNR, size: PT12, bold: true, color: "000000" },
    paragraph: {
      alignment: AlignmentType.LEFT,
      spacing: DBL,
      indent: { firstLine: 0 },
    },
  },

  // APA Level-3 heading: flush left, bold italic
  {
    id: "Heading3", name: "Heading 3",
    basedOn: "Normal", next: "Normal",
    run: { font: TNR, size: PT12, bold: true, italics: true, color: "000000" },
    paragraph: {
      alignment: AlignmentType.LEFT,
      spacing: DBL,
      indent: { firstLine: 0 },
    },
  },

  // Block quotation: 0.5" left indent, no first-line indent
  {
    id: "BlockQuote", name: "Block Text",
    basedOn: "Normal", next: "Normal",
    run: { font: TNR, size: PT12, color: "000000" },
    paragraph: {
      spacing: DBL,
      indent: { left: 720, firstLine: 0 },
    },
  },

  // ── Custom styles used by the Lua filter for title page / abstract ──────────

  // Title-page paper title: centered, bold
  {
    id: "TitlePageTitle", name: "TitlePageTitle",
    basedOn: "Normal",
    run: { font: TNR, size: PT12, bold: true, color: "000000" },
    paragraph: {
      alignment: AlignmentType.CENTER,
      spacing: DBL,
      indent: { firstLine: 0 },
    },
  },

  // Title-page body text (author, affiliation, course, etc.): centered, plain
  {
    id: "TitlePageText", name: "TitlePageText",
    basedOn: "Normal",
    run: { font: TNR, size: PT12, color: "000000" },
    paragraph: {
      alignment: AlignmentType.CENTER,
      spacing: DBL,
      indent: { firstLine: 0 },
    },
  },

  // Abstract heading: "Abstract" centered bold
  {
    id: "APAAbstractTitle", name: "APAAbstractTitle",
    basedOn: "Normal",
    run: { font: TNR, size: PT12, bold: true, color: "000000" },
    paragraph: {
      alignment: AlignmentType.CENTER,
      spacing: DBL,
      indent: { firstLine: 0 },
    },
  },

  // Abstract / keywords body: justified, NO first-line indent
  {
    id: "APAAbstractText", name: "APAAbstractText",
    basedOn: "Normal",
    run: { font: TNR, size: PT12, color: "000000" },
    paragraph: {
      alignment: AlignmentType.BOTH,
      spacing: DBL,
      indent: { firstLine: 0 },
    },
  },
];

// ─── Document ─────────────────────────────────────────────────────────────────

const doc = new Document({
  creator: "APA-Pipeline",
  description: "Pandoc reference document — APA 7th edition (student paper)",
  styles: {
    default: {
      document: { run: { font: TNR, size: PT12 } },
    },
    paragraphStyles,
  },
  sections: [
    {
      properties: {
        page: {
          size: { width: 12240, height: 15840 },   // US Letter
          margin: MARGINS,
        },
      },
      // Header: page number flush right (APA 7 student paper requirement)
      headers: {
        default: new Header({
          children: [
            new Paragraph({
              alignment: AlignmentType.RIGHT,
              children: [
                new TextRun({
                  font: TNR,
                  size: PT12,
                  children: [PageNumber.CURRENT],
                }),
              ],
            }),
          ],
        }),
      },
      // Placeholder body so the document is valid
      children: [
        new Paragraph({
          style: "Normal",
          children: [new TextRun("")],
        }),
      ],
    },
  ],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync("apa-reference.docx", buf);
  console.log("✓  apa-reference.docx written");
});
