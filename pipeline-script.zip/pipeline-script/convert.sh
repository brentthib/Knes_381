#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
#  convert.sh  —  Markdown → APA 7th Edition DOCX (and optionally PDF)
#
#  Usage:
#    ./convert.sh my-paper.md                  # outputs my-paper_APA.docx
#    ./convert.sh my-paper.md output.docx      # custom output name
#    ./convert.sh my-paper.md output.pdf       # PDF via LibreOffice
#
#  Requirements:
#    • pandoc  ≥ 2.11   https://pandoc.org/installing.html
#    • (PDF only) LibreOffice  https://www.libreoffice.org
#    • apa.csl is downloaded automatically on first run
#
#  All pipeline files (apa-reference.docx, apa-filter.lua, apa.csl) are
#  expected to live in the same directory as this script.
# ─────────────────────────────────────────────────────────────────────────────

set -euo pipefail

# ── Arguments ─────────────────────────────────────────────────────────────────
INPUT="${1:-}"
if [[ -z "$INPUT" ]]; then
  echo "Usage: $0 <input.md> [output.docx|output.pdf]"
  exit 1
fi
if [[ ! -f "$INPUT" ]]; then
  echo "Error: file not found — $INPUT"
  exit 1
fi

BASENAME="${INPUT%.md}"
OUTPUT="${2:-${BASENAME}_APA.docx}"
EXT="${OUTPUT##*.}"

# ── Locate pipeline directory ─────────────────────────────────────────────────
PIPELINE_DIR="$(cd "$(dirname "$0")" && pwd)"
REF_DOC="$PIPELINE_DIR/apa-reference.docx"
LUA_FILTER="$PIPELINE_DIR/apa-filter.lua"

# ── Dependency checks ─────────────────────────────────────────────────────────
if ! command -v pandoc &>/dev/null; then
  echo "Error: pandoc is not installed."
  echo "       Install from https://pandoc.org/installing.html"
  exit 1
fi

PANDOC_MAJOR=$(pandoc --version | head -1 | grep -oE '[0-9]+' | head -1)
if [[ "$PANDOC_MAJOR" -lt 2 ]]; then
  echo "Warning: pandoc < 2.x detected. Version 2.11+ is recommended."
fi

# ── Download APA CSL on first run ─────────────────────────────────────────────
CSL_FILE="$PIPELINE_DIR/apa.csl"
if [[ ! -f "$CSL_FILE" ]]; then
  echo "→ Downloading APA citation style (apa.csl) …"
  CSL_URL="https://raw.githubusercontent.com/citation-style-language/styles/master/apa.csl"
  if command -v curl &>/dev/null; then
    curl -fsSL -o "$CSL_FILE" "$CSL_URL"
  elif command -v wget &>/dev/null; then
    wget -q -O "$CSL_FILE" "$CSL_URL"
  else
    echo "Error: neither curl nor wget found. Download apa.csl manually from:"
    echo "       $CSL_URL"
    exit 1
  fi
  echo "✓  apa.csl saved."
fi

# ── Build pandoc arguments ────────────────────────────────────────────────────
# pandoc 2.11+ has --citeproc built in; earlier versions need --filter pandoc-citeproc
EXTRA_ARGS=""
if grep -q "^bibliography:" "$INPUT" 2>/dev/null; then
  PANDOC_MINOR=$(pandoc --version | head -1 | grep -oE '[0-9]+' | sed -n '2p')
  if [[ "$PANDOC_MAJOR" -gt 2 ]] || [[ "$PANDOC_MAJOR" -eq 2 && "$PANDOC_MINOR" -ge 11 ]]; then
    EXTRA_ARGS="--citeproc --csl=$CSL_FILE"
  elif command -v pandoc-citeproc &>/dev/null; then
    EXTRA_ARGS="--filter pandoc-citeproc --csl=$CSL_FILE"
  else
    echo "⚠  Warning: bibliography found but neither pandoc ≥2.11 (--citeproc)"
    echo "            nor pandoc-citeproc filter is available."
    echo "            References will not be processed. Install pandoc 2.11+ to fix."
  fi
fi

# ── Convert to DOCX ───────────────────────────────────────────────────────────
DOCX_OUT="$OUTPUT"
if [[ "$EXT" == "pdf" ]]; then
  DOCX_OUT="${BASENAME}_APA_tmp.docx"
fi

echo "→ Converting $INPUT → $DOCX_OUT …"

pandoc "$INPUT" \
  --reference-doc="$REF_DOC" \
  --lua-filter="$LUA_FILTER" \
  $EXTRA_ARGS \
  --output="$DOCX_OUT"

echo "✓  $DOCX_OUT written."

# ── Optional: DOCX → PDF via LibreOffice ─────────────────────────────────────
if [[ "$EXT" == "pdf" ]]; then
  if ! command -v libreoffice &>/dev/null && ! command -v soffice &>/dev/null; then
    echo ""
    echo "⚠  PDF requested but LibreOffice was not found."
    echo "   Install from https://www.libreoffice.org, or open the DOCX in"
    echo "   Microsoft Word and use File → Save As → PDF."
    echo "   The DOCX has been saved as: $DOCX_OUT"
    exit 0
  fi

  SOFFICE=$(command -v libreoffice || command -v soffice)
  OUT_DIR="$(dirname "$OUTPUT")"
  echo "→ Converting DOCX → PDF via LibreOffice …"
  "$SOFFICE" --headless --convert-to pdf --outdir "$OUT_DIR" "$DOCX_OUT"

  # LibreOffice names the file after the input; rename to desired output
  LO_PDF="${DOCX_OUT%.docx}.pdf"
  if [[ "$LO_PDF" != "$OUTPUT" ]]; then
    mv "$LO_PDF" "$OUTPUT"
  fi

  rm -f "$DOCX_OUT"   # remove temp DOCX
  echo "✓  $OUTPUT written."
fi
