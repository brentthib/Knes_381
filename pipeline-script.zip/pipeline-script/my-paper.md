---
# ═══════════════════════════════════════════════════════
#  APA 7th Edition — Student Paper Template
#  Fill in the fields below, then write your paper below
#  the YAML block (after the closing ---).
# ═══════════════════════════════════════════════════════

title: "Mechanisms of Skeletal Muscle Fatigue During Repeated High-Intensity Exercise"

# For multiple authors use a list:
#   author:
#     - "Jane Smith"
#     - "John Doe"
author: "Student Name"

affiliation: "Faculty of Kinesiology, University of Calgary"

course: "KNES 500: Advanced Exercise Physiology"

instructor: "Dr. Instructor Name"

due-date: "April 7, 2026"

# Abstract (150–250 words for most student papers).
# Remove this block entirely if no abstract is required.
abstract: |
  Skeletal muscle fatigue represents a complex, multifactorial phenomenon that
  limits performance during repeated bouts of high-intensity exercise. Although
  traditionally attributed to metabolic acidosis arising from lactate and
  proton accumulation, contemporary evidence implicates a broader set of
  mechanisms including inorganic phosphate accumulation at the myofilament
  level, reactive oxygen species–mediated impairment of excitation–contraction
  coupling, and central nervous system modulation of motor drive. This paper
  reviews the current mechanistic understanding of peripheral and central
  fatigue, with particular attention to cross-bridge kinetics and sarcoplasmic
  reticulum Ca²⁺ handling. Implications for training prescription and recovery
  strategies in applied sport and clinical populations are discussed. Future
  research directions, including single-fibre proteomics and in vivo
  phosphorus magnetic resonance spectroscopy, are identified.

keywords: "skeletal muscle fatigue, excitation–contraction coupling, calcium, high-intensity exercise"

# ── Bibliography ────────────────────────────────────────
# Point to your .bib file. Delete or comment out if unused.
bibliography: references.bib

# APA citation style (download apa.csl — see convert.sh).
csl: apa.csl
---

# Introduction

Skeletal muscle fatigue is broadly defined as an exercise-induced reduction in
maximal force or power output [@Allen2008]. Despite decades of investigation,
the precise sequence of events linking metabolic perturbation to contractile
failure remains contested. Early paradigms emphasised intracellular acidosis
[@Fitts1994], yet more recent work has shifted focus to inorganic phosphate
(Pᵢ) accumulation and its direct effects on cross-bridge cycling [@Westerblad2002].

## Peripheral Fatigue Mechanisms

Peripheral fatigue originates within the muscle fibre itself and can be
further subdivided into high-frequency and low-frequency fatigue based on the
stimulation frequencies that reveal the force deficit.

### Inorganic Phosphate and Cross-Bridge Kinetics

During intense exercise, creatine phosphate hydrolysis releases Pᵢ at a rate
that exceeds its re-uptake into the sarcoplasmic reticulum. Accumulated Pᵢ
reduces the proportion of force-generating cross-bridges in the strong-binding
state, lowering peak isometric force by up to 30% in isolated fibres [@Allen2008].

### Sarcoplasmic Reticulum Ca²⁺ Handling

Repeated action potentials deplete releasable Ca²⁺ stores within the
sarcoplasmic reticulum. Reactive oxygen species generated during high-intensity
work further impair ryanodine receptor function, reducing the amplitude of the
cytosolic Ca²⁺ transient and thus limiting cross-bridge activation
[@Westerblad2002; @Allen2008].

## Central Fatigue

Central fatigue is defined as a progressive, exercise-induced decline in
voluntary motor drive that is reversible upon cessation of effort [@Gandevia2001].
Supraspinal contributions include altered corticospinal excitability and
increased inhibitory feedback from group III/IV muscle afferents.

# Methods

> **Note:** Replace this section with your own methods. A block quotation
> is formatted like this — indented 0.5 inch on the left per APA style.

Participants performed an incremental cycling test to volitional exhaustion
followed by three repeated 30-second Wingate bouts with 4-minute recovery
intervals. Vastus lateralis biopsies were obtained immediately pre- and
post-exercise for metabolite and protein analyses.

# Results

Peak power output declined by 18 ± 4% across the three Wingate bouts
(p < 0.001). Muscle Pᵢ increased 4.5-fold above resting values by the end of
the third bout. These findings align with cross-bridge inhibition models
proposed by @Westerblad2002.

# Discussion

The present data support a Pᵢ-mediated mechanism of fatigue during repeated
sprint exercise, consistent with the fibre-type specific responses reported by
@Allen2008. The contribution of central fatigue appeared secondary under these
conditions, as evidenced by unchanged superimposed twitch amplitude at task
failure.

## Limitations

Single-fibre measurements were not obtained in the current study, precluding
analysis of type I versus type II fibre contributions to the observed force
deficit.

# Conclusion

Skeletal muscle fatigue during repeated high-intensity exercise reflects the
convergent action of inorganic phosphate accumulation, impaired Ca²⁺ cycling,
and, to a lesser extent, reduced central motor drive. Future studies combining
in vivo ^31^P-MRS with single-fibre proteomics will be necessary to resolve
remaining mechanistic ambiguities.

# References

<!-- Pandoc inserts the formatted reference list here automatically -->
