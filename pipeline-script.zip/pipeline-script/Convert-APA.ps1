<#
.SYNOPSIS
    Converts a Markdown file to an APA 7th Edition DOCX (Windows version).

.DESCRIPTION
    Wraps pandoc with the APA reference document, Lua filter, and APA CSL
    citation style to produce a properly formatted student paper.

.PARAMETER InputFile
    Path to the source Markdown file (must contain a YAML header).

.PARAMETER OutputFile
    Destination .docx path.  Defaults to <InputBaseName>_APA.docx in the
    same directory as the input file.

.EXAMPLE
    .\Convert-APA.ps1 my-paper.md
    .\Convert-APA.ps1 my-paper.md "C:\Papers\final_draft.docx"

.NOTES
    Requires pandoc 2.11+  https://pandoc.org/installing.html
    Optional: Microsoft Word or LibreOffice to open the resulting .docx.
#>

param(
    [Parameter(Mandatory=$true,  Position=0)] [string]$InputFile,
    [Parameter(Mandatory=$false, Position=1)] [string]$OutputFile = ""
)

$ErrorActionPreference = "Stop"

# ── Resolve paths ──────────────────────────────────────────────────────────────
$ScriptDir   = Split-Path -Parent $MyInvocation.MyCommand.Path
$InputFile   = Resolve-Path $InputFile
$BaseName    = [System.IO.Path]::GetFileNameWithoutExtension($InputFile)

if ($OutputFile -eq "") {
    $OutputDir  = Split-Path -Parent $InputFile
    $OutputFile = Join-Path $OutputDir "${BaseName}_APA.docx"
}

$RefDoc    = Join-Path $ScriptDir "apa-reference.docx"
$LuaFilter = Join-Path $ScriptDir "apa-filter.lua"
$CslFile   = Join-Path $ScriptDir "apa.csl"

# ── Check pandoc ───────────────────────────────────────────────────────────────
if (-not (Get-Command pandoc -ErrorAction SilentlyContinue)) {
    Write-Error "pandoc not found. Install from https://pandoc.org/installing.html"
    exit 1
}

# ── Download APA CSL if needed ─────────────────────────────────────────────────
if (-not (Test-Path $CslFile)) {
    Write-Host "Downloading apa.csl ..."
    $CslUrl = "https://raw.githubusercontent.com/citation-style-language/styles/master/apa.csl"
    Invoke-WebRequest -Uri $CslUrl -OutFile $CslFile
    Write-Host "✓  apa.csl saved."
}

# ── Build pandoc command ───────────────────────────────────────────────────────
$Content = Get-Content $InputFile -Raw
$ExtraArgs = @()
if ($Content -match "(?m)^bibliography:") {
    $ExtraArgs = @("--citeproc", "--csl=$CslFile")
}

# ── Run pandoc ─────────────────────────────────────────────────────────────────
Write-Host "Converting $InputFile → $OutputFile ..."

$PandocArgs = @(
    $InputFile,
    "--reference-doc=$RefDoc",
    "--lua-filter=$LuaFilter"
) + $ExtraArgs + @("--output=$OutputFile")

& pandoc @PandocArgs

if ($LASTEXITCODE -ne 0) {
    Write-Error "pandoc exited with code $LASTEXITCODE"
    exit $LASTEXITCODE
}

Write-Host "✓  $OutputFile written."
