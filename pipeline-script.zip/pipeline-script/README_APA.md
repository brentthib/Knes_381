# README — APA 7 Paper (Markdown → Word)

## Overview
This setup lets you write your paper in Markdown and convert it into a properly formatted APA 7 Word document.

You do not need to understand Pandoc internals. You only need to run one command.

---

## What you need installed

### Required
- Pandoc (document converter)

### Optional (only if exporting PDF)
- LibreOffice (office suite)

---

## Files you will use

- my-paper.md → your paper (you edit this)
- convert.sh or Convert-APA.ps1 → conversion script
- apa-reference.docx → formatting template (do not edit)
- apa-filter.lua → formatting automation (do not edit)

---

## Step 1 — Write your paper

Open my-paper.md.

At the top, fill in the YAML block:

title: "Your Paper Title"
author: "Your Name"
affiliation: "University of Calgary"
course: "KNES XXX"
instructor: "Instructor Name"
due-date: "April 7, 2026"

bibliography: references.bib
csl: apa.csl

Then write your paper below.

---

## Step 2 — Add citations (if needed)

In your text:
Exercise induces fatigue [@Allen2008].

Pandoc will automatically format:
- in-text citations
- reference list

---

## Step 3 — Convert to Word

### On macOS / Linux
./convert.sh my-paper.md

### On Windows
.\Convert-APA.ps1 my-paper.md

---

## Output

You will get:
my-paper_APA.docx

This file is:
- APA formatted
- properly spaced
- includes title page and abstract (if provided)

---

## Optional — Export to PDF

./convert.sh my-paper.md output.pdf

(Requires LibreOffice)

---

## Important notes

- Do not edit:
  - apa-reference.docx
  - apa-filter.lua
- These files control formatting automatically
- If formatting looks wrong, ask for help instead of modifying them

---

## Common mistakes

- Missing YAML fields → title page will be incomplete  
- Forgetting bibliography → references won’t appear  
- Editing the template file → formatting breaks  

---

## Summary

1. Write → my-paper.md  
2. Run one command  
3. Submit → .docx  
